import React from 'react'

const Footer = () => {
  return (
    <div className='mt-4'>
      
    </div>
  )
}

export default Footer
